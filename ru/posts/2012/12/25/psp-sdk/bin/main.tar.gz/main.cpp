#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>

#define printf pspDebugScreenPrintf

PSP_MODULE_INFO("Test", 0, 1, 1);

// Exit callback
int ExitCallback(int Arg1, int Arg2, void *Common)
{
    sceKernelExitGame();
    return 0;
}

// Callback thread
int CallbackThread(SceSize Args, void *Argp)
{
    int CallbackId;

    CallbackId = sceKernelCreateCallback("Exit Callback", ExitCallback, NULL);
    sceKernelRegisterExitCallback(CallbackId);

    sceKernelSleepThreadCB();

    return 0;
}

// Sets up the callback thread and returns its thread id
int SetupCallbacks(void)
{
    int ThreadId = 0;

    ThreadId = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if (ThreadId >= 0)
    {
        sceKernelStartThread(ThreadId, 0, 0);
    }

    return ThreadId;
}

int main(int argc, char ** argv)
{
    pspDebugScreenInit();
    SetupCallbacks();

    printf("Hello World \n");

    sceKernelSleepThread();

    return 0;
}
